// Enable memory leak detection in non-CObject based code.

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

