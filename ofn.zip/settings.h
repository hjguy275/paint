#ifndef __SETTINGS_H__
#define __SETTINGS_H__

extern void LoadRegistorSettings();
extern void SaveRegistorSettings();

#endif // __SETTINGS_H__
