// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//
#include <afxcmn.h>         // for tooltips
#include <afxwin.h>         // MFC core and standard components
#include <objbase.h>
#include <afxext.h>         // MFC extensions (including VB)
#include <afxole.h>         // MFC OLE classes
#include <afxpriv.h>

#include <sti.h>
#include <wia.h>
#include <wiadevdp.h>

#include <gdiplus/gdiplus.h>

#include <UxTheme.h>
#include <TmSchema.h>

#include "bar.h"
